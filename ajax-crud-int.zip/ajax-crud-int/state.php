<?php
$conn=mysqli_connect("localhost","root","","ajax-crud-int","3307");
$id=$_POST['conID'];
    $sql="SELECT * FROM city where state_id=".$_POST['conID'];
    $result=mysqli_query($conn,$sql);
    $output="";
    while($row=mysqli_fetch_assoc($result)){
        $output.='<option '.$row['id'].' >'.$row['city'].'</option>';
    }
    echo $output;
        
        

    


?>