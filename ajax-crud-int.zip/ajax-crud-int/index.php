<?php
$conn=mysqli_connect("localhost","root","","ajax-crud-int","3307");
$sql="SELECT * FROM state";

$result=mysqli_query($conn,$sql);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="css/style.css">
</head>

<body>
    <script>
        function validateForm(){
            var age=document.getElementById("fage").value;
if(age == "")     
    return true;

//check if age is a number or less than or greater than 100
if (isNaN(age)||age<=18)
{ 
    alert("The age is must be greater than 18");
    return false;

}}
    </script>
   
    <div class="container">
        <table>
            <tr>
                <td id="table-form">
                    <form id="addForm">
                        
                        Name:<input type="name" id="fname" >
                        Age:<input type="number" id="fage" min="18" onchange="validateForm() ">
                        <select id="fstate" >
                            <option value="">select state</option>
                            <?php
                            if(mysqli_num_rows($result)>0){
                                while($row=mysqli_fetch_assoc($result)){
                                    echo '<option value="'.$row['id'].'">'.$row['state'].'</option>';

                                }
                            }
                            ?>

                        </select>
                        <select id="fcity">
                            
                            
                        </select>
                        <input type="submit" id="save-button" value="save">
                    </form>
                </td>
            </tr>

            <tr>
                <table>
                    <tr>
                        <td id="table-data">

                        </td>
                    <tr>
                </table>
            </tr>


        </table>

        <div id="modal">

            <div id="modal-form">
                <table>
                    <!-- <tr>
                        <td><input type="name" id="edit-fname"></td>
                    </tr>
                    <tr>
                        <td><input type="number" id="edit-fage"></td>
                    </tr>
                    <tr>
                        <td>
                            <select id="edit-fstate">
                                <option value="">select state</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <select id="edit-fcity">
                                <option value="">select country</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td> <input type="submit" id="edit-submit" value="save"></td>

                    </tr> -->

                </table>
                <div id="close-btn">X</div>


            </div>


        </div>



        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                function loadTable() {
                    $.ajax({
                        url: "fetchdata.php",
                        type: "POST",
                        success: function(data) {
                            $("#table-data").html(data);
                            $("#")
                           
                        }

                    });
                }

                loadTable();

                $("#save-button").on("click", function(e) {
                    e.preventDefault();
                    var f_name = $("#fname").val();
                    var f_age = $("#fage").val();
                    var f_state = $("#fstate").val();
                    var f_city = $("#fcity").val();

                    $.ajax({
                        url: "ajax-insert.php",
                        type: "POST",
                        data: {
                            first_name: f_name,
                            first_age: f_age,
                            first_state: f_state,
                            first_city: f_city
                        },
                        success: function(data) {
                            if (data == 1) {
                                loadTable();
                            } else {
                                alert("cant save data");
                            }

                        }

                    })


                })

                $(document).on("click", ".delete-btn", function() {
                    var studentId = $(this).data("id");
                    var elem = this;
                    $.ajax({
                        url: "ajax-delete.php",
                        type: "POST",
                        data: {
                            id: studentId
                        },
                        success: function(data) {
                            $(elem).closest("tr").fadeOut();

                        }
                    })
                })

                $(document).on("click", ".edit-btn", function() {
                    $("#modal").show();
                    var studentId = $(this).data("eid");
                    $.ajax({
                        url: "load-update-form.php",
                        type: "POST",
                        data: {
                            id: studentId
                        },
                        success: function(data) {
                            $("#modal-form table").html(data);

                        }

                    })
                })

                $("#close-btn").on("click", function() {
                    $("#modal").hide();
                })

                $(document).on("click", "#edit-submit", function() {
                    var fid = $("#edit-id").val();
                    var fname = $("#edit-fname").val();
                    var fage = $("#edit-fage").val();
                    var fstate = $("#edit-fstate").val();
                    var fcity = $("#edit-fcity").val();

                    $.ajax({
                        url: "ajax-update-form.php",
                        type: "POST",
                        data: {
                            id: fid,
                            name: fname,
                            age: fage,
                            state: fstate,
                            city: fcity
                        },
                        success: function(data) {
                            if (data == 1) {
                                $("#modal").hide();
                                loadTable();
                            }
                        }
                    })
                });

                $("#fstate").change(function(){
                    var countryID=$("#fstate").val();
                    if(countryID){
                        $.ajax({
                            url:"state.php",
                            type:"POST",
                            data:{conID:countryID},
                            success:function(data){
                                $("#fcity").html(data);

                            }

                        })
                    }
                })
            })

//             var age=document.getElementById('fage').value;
// if(age == "")     
//     return true;

// //check if age is a number or less than or greater than 100
// if (isNaN(age)||age<=18)
// { 
//     alert("The age is must be greater than 18");
//     return false;
// }

        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>