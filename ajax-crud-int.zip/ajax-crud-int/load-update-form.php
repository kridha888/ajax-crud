<?php
$student_id=$_POST["id"];
$conn=mysqli_connect("localhost","root","","ajax-crud-int","3307");
$sql="SELECT * FROM student WHERE id={$student_id}";
$result=mysqli_query($conn,$sql);
$output="";
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        $output.="<tr>

        <td>
        <input type='text' id='edit-id' hidden value='{$row["id"]}'>
        <input type='name' id='edit-fname' value='{$row["name"]}'></td>
    </tr>
    <tr>
        <td><input type='number' id='edit-fage' value='{$row["age"]}' ></td>
    </tr>
    <tr>
        <td>
        <select id='edit-fstate'>
        <option value=''>select state</option>
        <option value=''>select state</option>
        <option value='maharashtra'>maharashtra</option>
        <option value='gujrat'>gujrat</option>
        <option value='goa'>goa</option>
        </select>
        </td>
    </tr>
    <tr>
        <td>
        <select id='edit-fcity'>
            <option value=''>select city</option>
            <option value='mumbai'>mumbai</option>
            <option value='baroda'>baroda</option>
            <option value='surat'>surat</option>
            <option value='panjim'>panjim</option>
            <option value='thivim'>thivim</option>
        </select>
        </td>
    </tr>
    <tr>
        <td> <input type='submit' id='edit-submit' value='save'></td>

    </tr>";
    }
    mysqli_close($conn);
    echo $output;
}

?>
