<?php
$id = $_POST["id"];
$name = $_POST["name"];
$age = $_POST["age"];
$state = $_POST["state"];
$city= $_POST["city"];

$conn = mysqli_connect("localhost","root","","test") or die("Connection Failed");

$sql = "UPDATE student SET name = '{$name}',age = '{$age}',state='{$state}',city='{$city}' WHERE id = {$id}";

if(mysqli_query($conn, $sql)){
  echo 1;
}else{
  echo 0;
}

?>
