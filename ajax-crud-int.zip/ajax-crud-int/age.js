var age=document.getElementById('fage').value;
if(age == "")     
    return true;

//check if age is a number or less than or greater than 100
if (isNaN(age)||age<1||age>100)
{ 
    alert("The age must be a number between 1 and 100");
    return false;
}