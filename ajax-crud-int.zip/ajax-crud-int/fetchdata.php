<?php
$conn=mysqli_connect("localhost","root","","ajax-crud-int","3307");
$sql="SELECT s.id,s.name,s.age,c.city,s.country,c.city,st.state FROM student AS s JOIN city as c on c.id=s.city JOIN state AS st on st.id=s.state;";
$result=mysqli_query($conn,$sql);
$output="";
if(mysqli_num_rows($result)>0){
    $output='<table class="table table-hover ">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">State</th>
                    <th scope="col">City</th>
                    <th scope="col">age</th>
                    <th scope="col">Delete</th>
                    <th scope="col">Edit</th>

                </tr>';
                while($row=mysqli_fetch_assoc($result)){
                    $output.="<tr>
                    <td>{$row["id"]}</td>
                    <td>{$row["name"]}</td>
                    <td>{$row["state"]}</td>
                    <td>{$row["city"]}</td>
                    <td>{$row["age"]}</td>
                    <td><button class='delete-btn' data-id='{$row["id"]}'>Delete</button></td> 
                    <td><button class='edit-btn' data-eid='{$row["id"]}'>Edit</button></td> 
                    </tr>";
                }

                $output.="</table>";

                mysqli_close($conn);

                echo $output;

    

}
?>