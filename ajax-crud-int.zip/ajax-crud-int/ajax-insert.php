<?php
$name=$_POST['first_name'];
$age=$_POST['first_age'];
$state=$_POST['first_state'];
$city=$_POST['first_city'];

$conn=mysqli_connect("localhost","root","","ajax-crud-int","3307");
$sql="INSERT INTO student (name,age,state,city) VALUES ('{$name}','{$age}','{$state}','{$city}') ";
if(mysqli_query($conn,$sql)){
    echo 1;
}else{
    echo 0;
}
?>